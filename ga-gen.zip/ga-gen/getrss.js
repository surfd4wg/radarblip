//modified by sidthetech@gmail.com




//given an alert ID!
const aid = process.argv[2];


//const arg1 = process.argv[2];

// These are reserved for later
//const arg2 = process.argv[3];

//These are reserved for later
//const arg3 = process.argv[4];


const fs = require('fs')
const alerts = require('google-alerts-api')
const { HOW_OFTEN, DELIVER_TO, HOW_MANY, SOURCE_TYPE } = alerts;
 
let alert_id = '';
let alert_rss = '';


alerts.configure({
    cookies: fs.readFileSync('cookies.data').toString(),
    password: 'Java22go',
    mail: 'g2foob@gmail.com'
});
 

alerts.sync(() => {

	var exists = false;
	alerts.getAlerts().forEach( al => {
		if(al.id == aid){
			exists = true;
			console.log(al.rss);
		}
	});
	if(!exists){
		console.log('err: does not exist');
	}

});
